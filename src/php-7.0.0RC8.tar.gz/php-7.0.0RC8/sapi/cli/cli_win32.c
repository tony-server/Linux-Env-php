#define PHP_CLI_WIN32_NO_CONSOLE 1
#include "php_cli.c"
