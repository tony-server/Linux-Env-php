.. _copyright:

Copyright
=========

.. code-block:: none

    Copyright (C) 1998-2000 Tobias Ratschiller <tobias_at_ratschiller.com>
    Copyright (C) 2001-2013 Marc Delisle <marc_at_infomarc.info>
        Olivier Müller <om_at_omnis.ch>
        Robin Johnson <robbat2_at_users.sourceforge.net>
        Alexander M. Turek <me_at_derrabus.de>
        Michal Čihař <michal_at_cihar.com>
        Garvin Hicking <me_at_supergarv.de>
        Michael Keck <mkkeck_at_users.sourceforge.net>
        Sebastian Mendel <cybot_tm_at_users.sourceforge.net>
        [check credits for more details]

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License version 2, as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see `http://www.gnu.org/licenses/
<http://www.gnu.org/licenses/>`_.
