#ifndef _PUTZ_H_
#define _PUTZ_H_

#include <QtGui>
#include "ui_putz.h"

class Putz : public QMainWindow, public Ui::MainWindow
{
   Q_OBJECT 

public:
   Putz();

public slots:

private:
};

#endif /* _PUTZ_H_ */
